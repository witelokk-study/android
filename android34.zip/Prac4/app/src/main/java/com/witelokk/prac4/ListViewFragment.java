package com.witelokk.prac4;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

public class ListViewFragment extends Fragment {
    public static class ListViewAdapter extends ArrayAdapter<String> {
        private final LayoutInflater inflater;
        private final int layout;
        private final List<String> items;

        public ListViewAdapter(Context context, int resource,
                               List<String> items) {
            super(context, resource, items);
            this.items = items;
            this.layout = resource;
            this.inflater = LayoutInflater.from(context);
        }

        @Override
        @NonNull
        public View getView(int position, View convertView,
                            @NonNull ViewGroup parent) {
            View view = inflater.inflate(this.layout, parent, false);
            String item = items.get(position);
            view.setOnClickListener(v -> {
                Toast.makeText(getContext(), item, Toast.LENGTH_SHORT).show();
                Log.d("list_view_adapter", "item " + item);
            });
            TextView textView = view.findViewById(R.id.textView);
            textView.setText(item);
            return view;
        }
    }

    public ListViewFragment() {
        super(R.layout.fragment_list_view);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ArrayList<String> strings = new ArrayList<>();
        for (int i = 0; i < 200; i++) {
            strings.add(Integer.valueOf(i).toString());
        }

        ListView listView = view.findViewById(R.id.list_view);
        listView.setAdapter(new ListViewAdapter(getContext(), R.layout.item, strings));
    }
}
