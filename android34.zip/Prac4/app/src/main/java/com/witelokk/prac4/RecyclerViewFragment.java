package com.witelokk.prac4;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class RecyclerViewFragment extends Fragment {
    class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
        private final LayoutInflater inflater;
        private final List<String> items;

        class ViewHolder extends RecyclerView.ViewHolder {
            private final View view;
            final TextView textView;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                view = itemView;
                textView = itemView.findViewById(R.id.textView);
            }

            public void setOnClickListener(View.OnClickListener l) {
                view.setOnClickListener(l);
            }
        }

        RecyclerViewAdapter(Context context, List<String> items) {
            this.inflater = LayoutInflater.from(context);
            this.items = items;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = inflater.inflate(R.layout.item, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            String item = items.get(position);
            holder.setOnClickListener(v -> {
                Toast.makeText(getContext(), item, Toast.LENGTH_SHORT).show();
                Log.d("recycler_view_adapter", "item " + item);
            });
            holder.textView.setText(item);
        }

        @Override
        public int getItemCount() {
            return items.size();
        }
    }

    public RecyclerViewFragment() {
        super(R.layout.fragment_recycler_view);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ArrayList<String> strings = new ArrayList<>();
        for (int i = 0; i < 200; i++) {
            strings.add(Integer.valueOf(i).toString());
        }

        RecyclerView recyclerView = view.findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(new RecyclerViewAdapter(getContext(), strings));
    }
}
