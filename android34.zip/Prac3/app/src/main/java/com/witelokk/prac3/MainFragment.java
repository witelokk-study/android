package com.witelokk.prac3;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class MainFragment extends Fragment {
    public MainFragment() {
        super(R.layout.fragment_main);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requireActivity().getSupportFragmentManager().registerFragmentLifecycleCallbacks(new FragmentManager.FragmentLifecycleCallbacks() {
            @Override
            public void onFragmentPreAttached(@NonNull FragmentManager fm, @NonNull Fragment f, @NonNull Context context) {
                super.onFragmentPreAttached(fm, f, context);
                Toast.makeText(getContext(), "onFragmentPreAttached", Toast.LENGTH_SHORT ).show();;
                Log.d("main_fragment_lifecycle", "onFragmentPreAttached");
            }

            @Override
            public void onFragmentAttached(@NonNull FragmentManager fm, @NonNull Fragment f, @NonNull Context context) {
                super.onFragmentAttached(fm, f, context);
                Toast.makeText(getContext(), "onFragmentAttached", Toast.LENGTH_SHORT ).show();;
                Log.d("main_fragment_lifecycle", "onFragmentAttached");
            }

            @Override
            public void onFragmentPreCreated(@NonNull FragmentManager fm, @NonNull Fragment f, @Nullable Bundle savedInstanceState) {
                super.onFragmentPreCreated(fm, f, savedInstanceState);
                Toast.makeText(getContext(), "onFragmentPreCreated", Toast.LENGTH_SHORT ).show();;
                Log.d("main_fragment_lifecycle", "onFragmentPreCreated");
            }

            @Override
            public void onFragmentCreated(@NonNull FragmentManager fm, @NonNull Fragment f, @Nullable Bundle savedInstanceState) {
                super.onFragmentCreated(fm, f, savedInstanceState);
                Toast.makeText(getContext(), "onFragmentCreated", Toast.LENGTH_SHORT ).show();;
                Log.d("main_fragment_lifecycle", "onFragmentCreated");
            }

            @Override
            public void onFragmentViewCreated(@NonNull FragmentManager fm, @NonNull Fragment f, @NonNull View v, @Nullable Bundle savedInstanceState) {
                super.onFragmentViewCreated(fm, f, v, savedInstanceState);
                Toast.makeText(getContext(), "onFragmentViewCreated", Toast.LENGTH_SHORT ).show();;
                Log.d("main_fragment_lifecycle", "onFragmentViewCreated");
            }

            @Override
            public void onFragmentStarted(@NonNull FragmentManager fm, @NonNull Fragment f) {
                super.onFragmentStarted(fm, f);
                Toast.makeText(getContext(), "onFragmentStarted", Toast.LENGTH_SHORT ).show();;
                Log.d("main_fragment_lifecycle", "onFragmentStarted");
            }

            @Override
            public void onFragmentResumed(@NonNull FragmentManager fm, @NonNull Fragment f) {
                super.onFragmentResumed(fm, f);
                Toast.makeText(getContext(), "onFragmentResumed", Toast.LENGTH_SHORT ).show();;
                Log.d("main_fragment_lifecycle", "onFragmentResumed");
            }

            @Override
            public void onFragmentPaused(@NonNull FragmentManager fm, @NonNull Fragment f) {
                super.onFragmentPaused(fm, f);
                Toast.makeText(getContext(), "onFragmentPaused", Toast.LENGTH_SHORT ).show();;
                Log.d("main_fragment_lifecycle", "onFragmentPaused");
            }

            @Override
            public void onFragmentStopped(@NonNull FragmentManager fm, @NonNull Fragment f) {
                super.onFragmentStopped(fm, f);
                Toast.makeText(getContext(), "onFragmentStopped", Toast.LENGTH_SHORT ).show();;
                Log.d("main_fragment_lifecycle", "onFragmentStopped");
            }

            @Override
            public void onFragmentSaveInstanceState(@NonNull FragmentManager fm, @NonNull Fragment f, @NonNull Bundle outState) {
                super.onFragmentSaveInstanceState(fm, f, outState);
                Toast.makeText(getContext(), "onFragmentSaveInstanceState", Toast.LENGTH_SHORT ).show();;
                Log.d("main_fragment_lifecycle", "onFragmentSaveInstanceState");
            }

            @Override
            public void onFragmentViewDestroyed(@NonNull FragmentManager fm, @NonNull Fragment f) {
                super.onFragmentViewDestroyed(fm, f);
                Toast.makeText(getContext(), "onFragmentViewDestroyed", Toast.LENGTH_SHORT ).show();;
                Log.d("main_fragment_lifecycle", "onFragmentViewDestroyed");
            }

            @Override
            public void onFragmentDestroyed(@NonNull FragmentManager fm, @NonNull Fragment f) {
                super.onFragmentDestroyed(fm, f);
                Toast.makeText(getContext(), "onFragmentDestroyed", Toast.LENGTH_SHORT ).show();;
                Log.d("main_fragment_lifecycle", "onFragmentDestroyed");
            }

            @Override
            public void onFragmentDetached(@NonNull FragmentManager fm, @NonNull Fragment f) {
                super.onFragmentDetached(fm, f);
                Toast.makeText(getContext(), "onFragmentDetached", Toast.LENGTH_SHORT ).show();;
                Log.d("main_fragment_lifecycle", "onFragmentDetached");
            }
        }, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        EditText nameEditText = view.findViewById(R.id.name_edit_text);
        Button nextButton = view.findViewById(R.id.next_button);

        nameEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                nextButton.setEnabled(!s.toString().isEmpty());
            }
        });

        requireActivity().getSupportFragmentManager().setFragmentResultListener("msg", this, (requestKey, result) -> {
            Toast.makeText(getActivity(), getString(R.string.result_from_hello, result.getString("text")), Toast.LENGTH_SHORT).show();
        });

        nextButton.setOnClickListener(v -> {
            Bundle bundle = new Bundle();
            bundle.putString("name", nameEditText.getText().toString());
            requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .setReorderingAllowed(true)
                    .replace(R.id.main, HelloFragment.class, bundle)
                    .addToBackStack(null)
                    .commit();
        });
    }
}
