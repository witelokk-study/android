package com.witelokk.prac3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class HelloFragment extends Fragment {
    public HelloFragment() {
        super(R.layout.fragment_hello);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        String name = getArguments() != null ? getArguments().getString("name") : "";
        TextView helloTextView = getView().findViewById(R.id.hello_text_view);
        helloTextView.setText(getString(R.string.hello, name));

        Button helloButton = getView().findViewById(R.id.hello_button);
        helloButton.setOnClickListener(v -> {
            Bundle bundle = new Bundle();
            bundle.putString("text", getString(R.string.just_hello));
            getParentFragmentManager().setFragmentResult("msg", bundle);
        });
    }
}
